angular.module('productDirective', [])
       .directive('product', function(){
  return {
    scope: { product: '=' },
    restrict: 'A',
    templateUrl: 'product.html',
    

    controller: function($scope, products){
      products.find($scope.product.id, function(product) {
        $scope.artURL = product.artURL;
      });
    }
  };
});
