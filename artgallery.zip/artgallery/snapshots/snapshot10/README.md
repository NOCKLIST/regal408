Initializing the model using an Angular controller, defined with a global function.
