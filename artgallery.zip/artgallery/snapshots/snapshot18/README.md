Enumerating objects - countries and their populations.
