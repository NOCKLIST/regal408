Removing names from a list using ng-click.

See also [http://docs.angularjs.org/api/ng/directive/ngController](http://docs.angularjs.org/api/ng/directive/ngController)
