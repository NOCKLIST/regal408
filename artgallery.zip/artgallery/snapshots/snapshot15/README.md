Adding entries to a list using forms and ng-submit.
