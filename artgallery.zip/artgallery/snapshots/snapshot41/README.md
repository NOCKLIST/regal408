Extracting the country details query into a service
