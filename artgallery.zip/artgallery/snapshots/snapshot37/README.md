Using links with routes for navigation between views
