Looping over lists in templates using ng-repeat.

Inspired by [Step 2 of the official Angular tutorial](http://docs.angularjs.org/tutorial/step_02).
