Building a table.
