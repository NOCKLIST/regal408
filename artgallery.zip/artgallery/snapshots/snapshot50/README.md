Extracting factories and directives to separate modules using method chaining.
