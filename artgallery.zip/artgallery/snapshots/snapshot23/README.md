Sorting in ng-repeat using orderBy
