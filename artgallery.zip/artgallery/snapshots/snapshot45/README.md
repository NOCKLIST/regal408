Simulating a RESTful service by splitting the JSON data across files.
