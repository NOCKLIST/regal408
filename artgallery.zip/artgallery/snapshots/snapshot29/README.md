Adding capital data.
