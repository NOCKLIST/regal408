Initializing the model using an Angular controller, defined within an Angular module.
