Adding country flag images.

Flag images and other data drawn from Wikipedia:

 * [China](http://en.wikipedia.org/wiki/China)
 * [India](http://en.wikipedia.org/wiki/India)
 * [United States](http://en.wikipedia.org/wiki/United_States)
