Extracting controllers into a separate module
