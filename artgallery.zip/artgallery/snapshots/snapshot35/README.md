Moving templates for routes into separate files
