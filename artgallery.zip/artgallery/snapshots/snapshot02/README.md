Added keyup event listener on textInput.
