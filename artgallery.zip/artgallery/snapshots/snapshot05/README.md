Updating a span when input text changes using jQuery.
