Starter HTML page with a text input
