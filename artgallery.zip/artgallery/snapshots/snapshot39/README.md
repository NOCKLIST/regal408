Surfacing data on the country details page
