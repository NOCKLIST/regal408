Creating a service for loading the list of countries.

Inspired by:

 * [Angular Dev Guide on Services](http://docs.angularjs.org/guide/dev_guide.services.understanding_services)
 * [Convert Angular HTTP.get function to a service on StackOverflow](http://stackoverflow.com/questions/13937318/convert-angular-http-get-function-to-a-service)
