Updating a template when input text changes using Angular.
