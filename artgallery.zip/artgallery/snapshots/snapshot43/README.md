Caching JSON using cache option

See [Angular docs on $http](http://docs.angularjs.org/api/ng/service/$http).
